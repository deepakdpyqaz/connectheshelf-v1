from django.apps import AppConfig


class DistributorConfig(AppConfig):
    name = 'distributor'
