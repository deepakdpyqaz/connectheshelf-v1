from django.contrib import admin
from distributor.models import Distributor, Payment,Book,Buybook,Rentbook
# Register your models here.
admin.site.register(Distributor)
admin.site.register(Payment)
admin.site.register(Book)
admin.site.register(Buybook)
admin.site.register(Rentbook)
