from django.shortcuts import render,HttpResponse,redirect
import numpy as np
import pandas as pd
from distributor.models import Book, Buybook,Distributor
# Create your views here.
def home(request):
    params={}
    if('reader' in request.session):
        actions=[{"name":"view books","link":""},{"name":"profile","link":"profile"},{"name":"request","link":"request"},{"name":"orders and requests","link":"view_order"}]
        params={'actions':actions}
    if('distrbutor' in request.session):
        actions=[{'name':'profile','link':''},{'name':'Manage books','link':'managebooks'},{'name':'View orders','link':'vieworders'}]
        params={'actions':actions}
    return render(request,'index.html',params)

def logout(request):
    if('reader' in request.session):
        del request.session['reader']
    if('distributor' in request.session):
        del request.session['distributor']
    return redirect('home')

def add(request):
    categories=['novel','childyoung','comics','exam','literature','religion','romance','textbook','thriller']
    user=Distributor.objects.filter(username='cts').first()
    for cat in categories:
        fname='data/'+cat+'.csv'
        df=pd.read_csv(fname)
        name=list(df['name'])
        author=list(df['author'])
        price=list(df['price'])
        for i in range(len(df)):
            if(price[i]!='0'):
                usrname=user
                nme=name[i]
                athor=author[i]
                poto=cat+'/'+name[i]+'.jpg'
                bok_type='buy'
                rting=4
                stock=10000
                pice=price[i]
                bk=Book(username=usrname,name=nme,author=athor,category=cat,photo=poto,book_type=bok_type,rating=rting)
                bk.save()
                bkb=Buybook(username=usrname,name=nme,stock=stock,price=pice)
                bkb.save()
    return HttpResponse('hello')

def edit(request):
    bk=Book.objects.filter().all()
    for b in bk:
        b.photo=str(b.photo)+'.jpg'
        b.save()
    return HttpResponse('edited')