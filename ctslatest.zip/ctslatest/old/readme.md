plans->click karne pe plan dikhne chahiye
donation->donate your books
get in touch->contact us 
events->events

blogs->influencer/top customer reviews

pricing -> price-15
proceed -> invoice with pricing

donate a book-> book details, address, name


accessory -> other book items

contact us -> 


font-family-> satisfy, knewave

E-book -> Add

member types

