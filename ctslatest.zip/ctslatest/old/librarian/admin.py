from django.contrib import admin
from librarian.models import Librarian,Issue
# Register your models here.
admin.site.register(Librarian)
admin.site.register(Issue)
