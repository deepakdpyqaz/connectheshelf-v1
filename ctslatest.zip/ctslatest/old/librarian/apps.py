from django.apps import AppConfig


class LibrarianConfig(AppConfig):
    name = 'librarian'
