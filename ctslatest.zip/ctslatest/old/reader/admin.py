from django.contrib import admin
from reader.models import Reader,Treader,Referral,Requestt
# Register your models here.
admin.site.register(Reader)
admin.site.register(Treader)
admin.site.register(Referral)
admin.site.register(Requestt)