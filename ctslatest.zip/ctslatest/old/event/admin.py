from django.contrib import admin
from event.models import Festbook,Festorder
# Register your models here.

admin.site.register(Festbook)
admin.site.register(Festorder)