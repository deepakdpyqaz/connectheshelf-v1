from django.contrib import admin
from home.models import Donation, Contact
# Register your models here.
admin.site.register(Donation)
admin.site.register(Contact)