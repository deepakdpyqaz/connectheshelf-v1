from django.contrib import admin
from reader.models import Reader,Coupon,Treader
# Register your models here.
admin.site.register(Reader)
admin.site.register(Coupon)
admin.site.register(Treader)
