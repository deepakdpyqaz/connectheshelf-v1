from django.shortcuts import render
from django.shortcuts import render, redirect
from django.http import HttpResponse,Http404
from django.template import loader
from django.template.loader import render_to_string
from reader.models import Reader,Treader,Coupon
from django.http import JsonResponse
from rest_framework.decorators import api_view
from datetime import datetime,date,timedelta
import random
from django.core.mail import send_mail
from django.utils.html import strip_tags
from distributor.extrafunctions import encrypter


actions=[{"name":"view books","link":""},{"name":"profile","link":"profile"},{"name":"request","link":"request"},{"name":"orders and requests","link":"view_order"}]
# Create your views here.
def home(request):
    pass


@api_view(['GET', 'POST'])
def login(request):
    if('reader' in request.session):
        return redirect('distributor_home')
    if(request.method == 'GET'):
        params = {'actions': actions, 'type': 'reader'}
        return render(request, 'login.html', params)
    if(request.method == 'POST'):
        username = request.data['username']
        password = request.data['password']
        params = {'verified': False}
        try:
            distr = Reader.objects.filter(username=username)
            if(len(distr) == 0):
                params['error'] = 'username incorrect'
            else:
                distr = distr.first()
                if(distr.password == password):
                    params['verified'] = True
                    request.session['reader'] = username
                    params['url'] = '/reader/profile'
                else:
                    params['error'] = 'password incorrect'
        except:
            params = {'error': 'server error'}
        return JsonResponse(params)
    raise Http404("Not found")

@api_view(['GET','POST'])
def signup(request):
    if('reader' in request.session):
        return redirect('reader_home')
    if(request.method == 'GET'):
        params = {'actions': actions, 'type': 'reader', 'Error': False}
        return render(request, 'reader/signup.html', params)
    if(request.method == 'POST'):
        name = request.data['name']
        email = request.data['email']
        contact = request.data['contact']
        username = request.data['username']
        password = request.data['password']
        age = request.data['age']
        otp = random.randint(10000, 999999)
        rdr = Reader.objects.filter(username=username)
        Error = []
        if(len(rdr) != 0):
            Error.append("Username not available.")
        rdr = Reader.objects.filter(email=email)
        if(len(rdr) != 0):
            Error.append("Email is already registered.")
        rdr = Reader.objects.filter(contact=contact)
        if(len(rdr) != 0):
            Error.append("contact is already registered.")
        if(Error):
            error=''
            for er in Error:
                error+=er+'<br>'
            params = {'verified': False, 'error': error}
            return JsonResponse(params)
        else:
            treader=Treader(username=username,name=name,contact=contact,age=age,email=email,password=password,otp=otp,status='pending')
            treader.save()
            html_message = render_to_string('mail/otp.html', {'name': name, 'otp': otp})
            plain_message = strip_tags(html_message)
            send_mail('ConnecTheShelf verification', plain_message, 'deepprak2001@gmail.com',[email], html_message=html_message, fail_silently=False)
            params={'verified':True,'url':False,'otp':True,'callback':'/reader/verify'}
            return JsonResponse(params)


@api_view(['GET','POST'])
def verify(request):
    if(request.method=='POST'):
        name = request.data['name']
        email = request.data['email']
        contact = request.data['contact']
        username = request.data['username']
        password = request.data['password']
        age = request.data['age']
        otp = request.data['otp']

        try:
            treader=Treader.objects.filter(username=username,status='pending').last()
            if(treader.otp==int(otp)):
                rdr = Reader(username=username, name=name, contact=contact,age=age, email=email, password=password,address='')
                rdr.save()
                rdr=Reader.objects.get(username=username)
                coupon=Coupon(username=rdr,coupon=encrypter(rdr.username),used_by=0,max_limit=5)
                coupon.save()
                treader.delete()
                params={'verified':True,'url':'/reader/login'}
                print(params)
                return JsonResponse(params)
            else:
                params={'verified':False,'error':'OTP invalid'}
                return JsonResponse(params)
        except:
            params={'verified':False,'error':'Time out'}
            return JsonResponse(params)

def profile(request):
    if('reader' in request.session):
        if(request.method=='GET'):
            rdr=Reader.objects.get(username=request.session['reader'])
            ref=Coupon.objects.get(username=rdr)
            params={'actions':actions,'type':'reader','reader':rdr,'ref':ref}
            return render(request,'reader/profile.html',params)

        if(request.method=='POST'):
            name=request.POST['name']
            age=request.POST['age']
            password=request.POST['password']
            contact=request.POST['contact']
            address=request.POST['address']
            rdr=Reader.objects.get(username=request.session['reader'])
            email=rdr.email
            rdr.name=name
            rdr.age=age
            rdr.password=password
            rdr.address=address
            rdr.save()
            html_message=render_to_string('mail/changedetails.html',{'name':name})
            plain_message=strip_tags(html_message)
            send_mail('ConnecTheShelf Change profile',plain_message,'deepprak2001@gmail.com',[email],html_message=html_message,fail_silently=False)
            return redirect('reader_profile')
        return redirect('reader_profile')


