from django.urls import path
from reader import views

urlpatterns=[
    path('',views.home,name='reader_home'),
    path('login',views.login,name='reader_login'),
    path('login/',views.login,name='reader_login'),
    path('signup',views.signup,name='reader_signup'),
    path('verify',views.verify,name='reader_verify'),
    path('profile',views.profile,name='reader_profile')
]